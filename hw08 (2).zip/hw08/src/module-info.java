/**
 * 
 */
/**
 * @author Polina
 *
 */
module hw08 {
	requires java.desktop;
}